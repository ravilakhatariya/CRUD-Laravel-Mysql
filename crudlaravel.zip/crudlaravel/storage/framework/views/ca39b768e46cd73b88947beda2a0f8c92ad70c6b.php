<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="<?php echo e(url('article/add')); ?>">
		<?php echo csrf_field(); ?>
title:<input type="text" name="title"><br>

description:<input type="text" name="description"><br>

author:
<input type="text" name="author" ><br>

<input type="submit" name="submit" value="submit"><br>
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\crudlaravel\resources\views/add.blade.php ENDPATH**/ ?>