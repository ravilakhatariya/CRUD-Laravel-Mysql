<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table border="2%"><tr>
	<th>Id</th>
	<th>title</th>
	<th>description</th>
	<th>author</th>
	<th>Action</th>
</tr>
<?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($req->id); ?></td>
	<td><?php echo e($req->title); ?></td>
	<td><?php echo e($req->description); ?></td>
	<td><?php echo e($req->author); ?></td>
	<td><button><a href="<?php echo e(url('article/update/'.$req->id)); ?>">
		update
	</a></button><button><a href="#" onclick="deletearticle(<?php echo e($req->id); ?>);">delete</a></button></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
</body>
</html>
<script type="text/javascript">
	function deletearticle(id){
		if(confirm('Are you sure you want to delete?')){
			window.location.href='<?php echo e(url('article/delete')); ?>/'+id;
		}
	}
</script><?php /**PATH C:\xampp\htdocs\crudlaravel\resources\views/list.blade.php ENDPATH**/ ?>