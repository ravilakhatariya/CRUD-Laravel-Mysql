<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="<?php echo e(url('article/edit/'.$article->id)); ?>">
		<?php echo csrf_field(); ?>
title:<input type="text" name="title" value="<?php echo e(old('title',$article->title)); ?>"><br>

description:<input type="text" name="description" value="<?php echo e(old('description',$article->description)); ?>"><br>

author:
<input type="text" name="author" value="<?php echo e(old('author',$article->author)); ?>"><br>

<input type="submit" name="submit" value="submit"><br>
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\crudlaravel\resources\views/edit.blade.php ENDPATH**/ ?>