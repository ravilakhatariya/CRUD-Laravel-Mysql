<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table border="2%"><tr>
	<th>Id</th>
	<th>title</th>
	<th>description</th>
	<th>author</th>
	<th>Action</th>
</tr>
@foreach($article as $req)
<tr>
	<td>{{$req->id}}</td>
	<td>{{$req->title}}</td>
	<td>{{$req->description}}</td>
	<td>{{$req->author}}</td>
	<td><button><a href="{{url('article/update/'.$req->id)}}">
		update
	</a></button><button><a href="#" onclick="deletearticle({{$req->id}});">delete</a></button></td>
</tr>
@endforeach

</table>
</body>
</html>
<script type="text/javascript">
	function deletearticle(id){
		if(confirm('Are you sure you want to delete?')){
			window.location.href='{{url('article/delete')}}/'+id;
		}
	}
</script>