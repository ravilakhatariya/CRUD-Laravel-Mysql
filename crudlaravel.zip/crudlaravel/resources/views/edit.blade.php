<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="{{url('article/edit/'.$article->id)}}">
		@csrf
title:<input type="text" name="title" value="{{old('title',$article->title)}}"><br>

description:<input type="text" name="description" value="{{old('description',$article->description)}}"><br>

author:
<input type="text" name="author" value="{{old('author',$article->author)}}"><br>

<input type="submit" name="submit" value="submit"><br>
</form>
</body>
</html>