<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="{{url('article/add')}}">
		@csrf
title:<input type="text" name="title"><br>

description:<input type="text" name="description"><br>

author:
<input type="text" name="author" ><br>

<input type="submit" name="submit" value="submit"><br>
</form>
</body>
</html>