<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/article','Articlecontroller@show');
Route::get('/article/add','Articlecontroller@store')->name('article.add');
Route::post('/article/add','Articlecontroller@save')->name('article.save');
Route::get('/article/delete/{id}','Articlecontroller@delete')->name('article.delete');
Route::get('/article/update/{id}','Articlecontroller@update')->name('article.update');
Route::post('/article/edit/{id}','Articlecontroller@edit')->name('article.edit');

Route::get('/', function () {
    return view('list');
});
