<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Article extends Model{
// // {
    	
// 	$flight = article::create([
//     'title' => 'title','description' => 'description','author' => 'author',
// ]);
}
